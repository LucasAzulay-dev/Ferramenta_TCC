def getIOarrays(filename):
    inputs = []
    outputs = []
    
    with open(filename, 'r') as file:
        for line in file:
            values = line.strip().split(' / ')
            
            inputs.append([int(inp) for inp in values[0].split()])
            outputs.append([int(out) for out in values[1].split()])
    
    return inputs, outputs

def findPairs(arrays):
    # Busca pares de arrays com apenas uma diferença e agrupa pela posição da diferença
    N = len(arrays)
    n = len(arrays[0])
    inputPairs = {i: [] for i in range(n)}
    
    for arr1 in range(N):
        for arr2 in range(arr1 + 1, N):
            # Encontra a posição da diferença
            diff_pos = -1
            for pos in range(n):
                if arrays[arr1][pos] != arrays[arr2][pos]:
                    if diff_pos == -1:
                        diff_pos = pos  # Primeira diferença encontrada
                    else:
                        diff_pos = -1  # Mais de uma diferença, ignora o par
                        break
            
            # Se há exatamente uma diferença
            if diff_pos != -1:
                inputPairs[diff_pos].append((arr1, arr2))
    
    return inputPairs

def checkOutput(inputPairs, outputs):
    # Confere se as entradas selecionadas também possuem variação nas saídas (para cada saída)
    numOut = len(outputs[0])
    checkedPairs = [dict() for output in range(numOut)]
    for output in range(numOut):
        for pos, pairs in inputPairs.items():
            checkedPairs[output][pos] = []
            for pair in pairs:
                if outputs[pair[0]][output] != outputs[pair[1]][output]:
                    checkedPairs[output][pos].append(pair)
    return checkedPairs

def summary(validPairs):
    # Gera uma saída informativa sobre o resultado
    numOut = len(validPairs)
    for out in range(numOut):
        validPairsOut = validPairs[out]
        inp_fail = []
        for pos, _ in validPairsOut.items():
            if validPairsOut[pos] == []:
                inp_fail.append(pos+1)
        
        num_fail = len(inp_fail)
        if num_fail==0:
            print(f"Todas as variáveis de entrada afetaram individualmente a saída {out+1}.")
        else:
            if(num_fail==1):
                print(f"A variável de entrada {inp_fail[0]} não exercitou a saída {out+1} individualmente.")
            else:
                fail_str = ','.join(map(str, inp_fail))
                print("As variáveis de entrada "+fail_str+f" não exercitaram a saída {out+1} individualmente.")

def checkModule(moduleName):
    print("\nConferindo cobertura do módulo: "+moduleName)

    filename = 'output/'+moduleName+'.txt'
    inputs, outputs = getIOarrays(filename)
    inputPairs = findPairs(inputs)
    validPairs = checkOutput(inputPairs, outputs)
    summary(validPairs)

        
checkModule("SUT")
checkModule("CompA")
checkModule("CompB")
checkModule("CompC")
checkModule("CompD")