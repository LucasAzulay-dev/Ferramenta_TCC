#include "save2file.h"
#include <stdio.h>

void writeInput(char *fName, int Inputs[], int numI){
    char path[128];
    sprintf(path, "output/%s", fName);
    FILE *f = fopen(path, "a");
    
    for(int i=0; i<numI; i++){
        fprintf(f, "%d", Inputs[i]);
        if(i < numI-1){
            fprintf(f, " ");
        }else{
            fprintf(f, " / ");
        }
    }
    fclose(f);
}

void writeOutput(char *fName, int Outputs[], int numO){
    char path[128];
    sprintf(path, "output/%s", fName);
    FILE *f = fopen(path, "a");
    
    for(int i=0; i<numO; i++){
        fprintf(f, "%d", Outputs[i]);
        if(i < numO-1){
            fprintf(f, " ");
        }else{
            fprintf(f, "\n");
        }
    }
    fclose(f);
}

// void writeInFile(char *fName, int IOv[], int numI, int numO){
//     int numIO = numI+numO;
//     char path[128];
//     sprintf(path, "output/%s", fName);
//     FILE *f = fopen(path, "a");
    
//     for(int i=0; i<numIO; i++){
//         fprintf(f, "%d", IOv[i]);
//         if(i < numIO-1){
//             if(i == numI-1){
//                 fprintf(f, " / ");
//             }else{
//                 fprintf(f, " ");
//             }
//         }else{
//             fprintf(f, "\n");
//         }
//     }
//     fclose(f);
// }