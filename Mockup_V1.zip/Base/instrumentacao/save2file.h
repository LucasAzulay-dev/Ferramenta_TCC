#ifndef INT_FUNC
#define INT_FUNC

void writeInput(char *fName, int Inputs[], int numI);

void writeOutput(char *fName, int Outputs[], int numO);

// void writeInFile(char *fName, int IOv[], int numI, int numO);

#endif //INT_FUNC