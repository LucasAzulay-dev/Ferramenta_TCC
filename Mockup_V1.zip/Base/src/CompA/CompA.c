# include "CompA.h"

void CompA (int AI1, int AI2, int AI3, int *AO1, int *AO2){
    *AO1 = AI1 + AI2;
    *AO2 = AI1 * AI3;
}