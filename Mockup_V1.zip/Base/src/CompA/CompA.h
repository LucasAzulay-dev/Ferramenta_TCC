#ifndef COMP_A
#define COMP_A

void CompA (int AI1, int AI2, int AI3, int *AO1, int *AO2);

#endif //COMP_A