# include "CompB.h"

void CompB (int BI1, int BI2, int BI3, int BI4, int *BO1){
    *BO1 = (BI1+BI2)*(BI3+BI4);
}