#ifndef COMP_B
#define COMP_B

void CompB (int BI1, int BI2, int BI3, int BI4, int *BO1);

#endif //COMP_B