# include "CompC.h"

void CompC (int CI1, int CI2, int *CO1){
    *CO1 = (CI1+CI2)*CI1;
}