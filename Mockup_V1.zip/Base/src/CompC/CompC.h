#ifndef COMP_C
#define COMP_C

void CompC (int CI1, int CI2, int *CO1);

#endif //COMP_C