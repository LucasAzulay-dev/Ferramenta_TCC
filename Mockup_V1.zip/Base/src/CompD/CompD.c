# include "CompD.h"

void CompD (int DI1, int DI2, int *DO1){
    *DO1 = (DI1-DI2)*DI2;
}