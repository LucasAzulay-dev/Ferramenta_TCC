#ifndef COMP_D
#define COMP_D

void CompD (int DI1, int DI2, int *DO1);

#endif //COMP_D