# include "../CompA/CompA.h"
# include "../CompB/CompB.h"
# include "../CompC/CompC.h"
# include "../CompD/CompD.h"
# include "../../instrumentacao/save2file.h"

#include<stdio.h>

#ifdef INSTRUMENT
    #define instrument 1
#else
    #define instrument 0
#endif

int AO1, AO2, BO1, CO1;

void SUT(int SUTI1, int SUTI2, int SUTI3, int SUTI4, int SUTI5, int SUTI6, int SUTI7, int *SUTO1){
    if(instrument){writeInput("SUT.txt", (int[]){SUTI1, SUTI2, SUTI3, SUTI4, SUTI5, SUTI6, SUTI7}, 7);}

    if(instrument){writeInput("CompA.txt", (int[]){SUTI1, SUTI2, SUTI3}, 3);}
    CompA(SUTI1, SUTI2, SUTI3, &AO1, &AO2);
    if(instrument){writeOutput("CompA.txt", (int[]){AO1, AO2}, 2);}

    if(instrument){writeInput("CompB.txt", (int[]){SUTI4, SUTI5, SUTI6, SUTI7}, 4);}
    CompB(SUTI4, SUTI5, SUTI6, SUTI7, &BO1);
    if(instrument){writeOutput("CompB.txt", (int[]){BO1}, 1);}

    if(instrument){writeInput("CompC.txt", (int[]){AO1, BO1}, 2);}
    CompC(AO1, BO1, &CO1);
    if(instrument){writeOutput("CompC.txt", (int[]){CO1}, 1);}

    if(instrument){writeInput("CompD.txt", (int[]){CO1, AO2}, 2);}
    CompD(CO1, AO2, SUTO1);
    if(instrument){writeOutput("CompD.txt", (int[]){*SUTO1},1);}
    
    if(instrument){writeOutput("SUT.txt", (int[]){*SUTO1}, 1);}
}