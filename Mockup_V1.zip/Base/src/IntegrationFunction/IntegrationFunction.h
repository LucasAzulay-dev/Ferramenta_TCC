#ifndef INT_FUNC
#define INT_FUNC

void SUT(int SUTI1, int SUTI2, int SUTI3, int SUTI4, int SUTI5, int SUTI6, int SUTI7, int *SUTO1);

#endif //INT_FUNC