# include "../CompA/CompA.h"
# include "../CompB/CompB.h"
# include "../CompC/CompC.h"
# include "../CompD/CompD.h"

int AO1, AO2, BO1, CO1;

void SUT(int SUTI1, int SUTI2, int SUTI3, int SUTI4, int SUTI5, int SUTI6, int SUTI7, int *SUTO1){
    CompA(SUTI1, SUTI2, SUTI3, &AO1, &AO2);
    CompB(SUTI4, SUTI5, SUTI6, SUTI7, &BO1);
    CompC(AO1, BO1, &CO1);
    CompD(CO1, AO2, SUTO1);    
}